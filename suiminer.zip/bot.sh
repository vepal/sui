node mine.js --fomo --meta --chain=mainnet --phrase="node mine.js --fomo --meta --chain=mainnet --phrase="suiprivkey1qpw3ja0v28fl8fq46qxjgdgj2qnendje49agpsnd49ecuvwuyqkvjycg3ek""
